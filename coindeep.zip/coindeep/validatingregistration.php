	<?php

	require_once("../connect/dbConnect.php");
	

	 

	if (isset($_POST["submitted"])) { // Handle the form.

	 

	// Check for a valid first name

	 

	if (preg_match ('%^[-_a-zA-Z ]{2,20}$%', stripslashes(trim($_POST["first_name"])))) {

	 

	$fn = escape_data($_POST["first_name"]);


	} else {

	 

	$ln = FALSE;

	 

	echo "<p><font color="red" size="+1">Please enter a valid first name!</font></p>";

	 

	}

	// Check for a valid last name

	 

	if (preg_match ("%^[-_a-zA-Z ]{2,30}$%", stripslashes(trim($_POST["last_name"])))) {

	 

	$ln = escape_data($_POST["last_name"]);

	 

	 

	} else {

	 

	$ln = FALSE;

	 

	echo "<p><font color="red" size="+1">Please enter a valid last name!</font></p>";

	 

	}

	 

	// Check for an email address.

	 

	if (preg_match ("%^[A-Za-z0-9._\%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$%", stripslashes(trim($_POST["email"])))) {

	 

	$e = escape_data($_POST["email"]);

	 

	} else {

	 

	$e = FALSE;

	 

	echo "<p><font color="red" size="+1">Please enter a valid email address!</font></p>";

	 

	}

	 

	// Check for a valid username

	 

	if (preg_match ("%\A(?=[-_a-zA-Z0-9]*?[A-Z])(?=[-_a-zA-Z0-9]*?[a-z])(?=[-_a-zA-Z0-9]*?[0-9])\S{8,}\z%", stripslashes(trim($_POST["u_name"])))) {

	 

	$un = escape_data($_POST["u_name"]);

	 } 
	 else {

	 

	$un = FALSE;

	 

	echo "<p><font color="red" size="+1">Please enter a valid username!</font></p>";

	 

	}

	 

	// Check for a password and match against the confirmed password.

	 

	if (preg_match ('%\A(?=[-_a-zA-Z0-9]*?[A-Z])(?=[-_a-zA-Z0-9]*?[a-z])(?=[-_a-zA-Z0-9]*?[0-9])\S{8,}\z%', stripslashes(trim($_POST["password1"])))) {

	 

	if (($_POST['p_word'] == $_POST['conf_pword']) && ($_POST["p_word"] != $_POST["u_name"])) {

	 

	$p = escape_data($_POST["p_word"]);

	 

	} elseif ($_POST["password1"] == $_POST["userid"]) {

	$p = FALSE;

	 

	echo "<p><font color="red" size="+1">Your password cannot be the same as your username</font></p>";

	} else {

	$p = FALSE;

	 

	echo "<p><font color="red" size="+1">Your password did not match the confirmed password!</font></p>";

	 

	}

	 

	} else {

	 

	$p = FALSE;

	 

	echo "<p><font color="red" size="+1">Please enter a valid password</font></p>";

	 

	}

	 
	if ($fn && $ln && $e && $p && $un) { // If everything’s OK.

	 

	// Make sure the userid is available.

	 

	$query = "SELECT username FROM members WHERE username='$un'";

	 

	$result = mysqli_query ($query) or trigger_error("Username Already Exists, Choose another username");

	 

	if (mysqli_num_rows($result) == 0) { // Available.

	 

	// Create the activation code.

	// Create a random number with rand.

	// Use it as a seed for uniqid, which when set to true generates a random number 23 digits in length

	// Use it to seed md5 that creates a random string 32 characters in length

	 

	/*$a = md5(uniqid(rand(), true));*/

	 

	// Add the user. By entering values in a different order from the form sql injection can be limited

	 

	$query = "INSERT INTO members (first_name, second_name, email, passwd,u_name,phone,country) VALUES ("$fn", "$ln", "$e", SHA("$p"), "$a", "$ui")";

	 

	// By using mysql_query I can make sure only one query is submitted blocking sql injection

	// Never use the php multi_query function

	$result = mysqli_query ($query) or trigger_error("Sorry an error occurred and the account could not be created");

	 

	// Check that the effected rows was equal to 1 in the last query. Should log if greater than

	if (mysqli_affected_rows() == 1) { // If it ran OK.

	 

	/*// Send the email.

	 

	$body = "Thank you for registering. To activate your account, please click on this link:<br />";

	 

	// mysql_insert_id() retrieves the value of the last auto_incremented id

	// Attach the random activation code in the link sent to the email

	$body .= “http://localhost/msgbrd/mbactivate.php?x=” . mysql_insert_id() . “&y=$a”;

	 

	mail($_POST[’email’], ‘Registration Confirmation’, $body, ‘From: derekbanas@verizon.net’);

	 

	 

	// Finish the page.

	 */

	/*echo "<br /><br /><h3>Thank you for registering! A confirmation email has been sent to your address. Please click on the link in that email in order to activate your account.</h3>’;

	*/ 

	exit();

	 

	} else { // If it did not run OK.

	 

	echo "<p><font color="red" size="+1">You could not be registered due to a system error. We apologize for any inconvenience.</font></p>";

	 

	}

	 

	} else { // The email address is not available.

	 

	echo "<p><font color="red" size="+1">That email address has already been registered. If you have forgotten your password, use the link to have your password sent to you.</font></p>";

	 

	}

	 

	 

	} else { // If one of the data tests failed.

	 

	echo "<p><font color="red" size="+1">Please try again.</font></p>";

	 

	}

	 

	 mysqli_close(); // Close the database connection.

	 

	} // End of the main Submit conditional.

	 

	?>