<?php

	require_once('/connect/dbConnect.php');
?>