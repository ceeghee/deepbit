  <?php
  	
  
  	require_once ("validation/header.php");
     require_once("connect/dbConnect.php");


    
    if(count($_POST)>0) 
    {

          foreach($_POST as $key=>$value) {
          if(empty($_POST[$key])){
               /* $message = ucwords($key) . " field is required";*/
                break;
          }
          }
  
    
    if($_SERVER["REQUEST_METHOD"]=="POST")
    {

      
      
      if(isset($_POST['submitted']))
      {
        
            
          function val_input($data)
          {
            $data=trim($data);
            $data= stripslashes($data);
            $data=htmlspecialchars($data);
            $data=($data);
            return $data;
          }

          
     

      $f_name=$l_name=$p_wrd=$c_pwrd=$u_wrd=$phne=$email=$country=$rf_name="";

            $spons=val_input($_POST["sponsor"]);
           $f_name= val_input($_POST["last_name"]);
           $l_name= val_input($_POST["last_name"]);
          $p_wrd= val_input($_POST["p_word"]);
          $c_pwrd= val_input($_POST["conf_pword"]);
          $u_wrd= val_input($_POST["u_name"]);
          $phne= val_input($_POST["mobile"]);
          $email= val_input($_POST["email"]);
          $country= val_input($_POST['country']);

      
      if(empty($_POST["sponsor"]))
      {
          $spons="coindeepadmin";
      }
      else
      {
          $query = "SELECT u_name FROM members WHERE u_name='$spons'";
          $result= @mysqli_query($dbc,$query);
         if ($result)
          {
          
            $rowcount=mysqli_num_rows($result);
              if($rowcount>0)
              {
                  $spons=val_input($_POST["sponsor"]);
                          
              }

              else
              {
                $spons="coindeepadmin";
              }
          }
      }
      
      if(empty($_POST["first_name"])){
          $message="Enter Valid Data for all fields";
         
      }
      else
      {
         $f_name= val_input($_POST["first_name"]);
        if (!preg_match("/^[a-zA-Z ]*$/",$f_name)) {
            $message = "Enter Valid data for all fields";
      }
      }
         

     if(empty($_POST["last_name"])){
          $message="Enter Valid Data for all fields";
         
      }
      else
      {
         $f_name= val_input($_POST["last_name"]);
        if (!preg_match("/^[a-zA-Z ]*$/",$l_name)){
            $message = "Enter Valid data for all fields";
      }
    }

      if(empty($_POST["p_word"]) OR empty($_POST["conf_pword"]))
      {
        $message= "Input Password";
        
      }

      else if($_POST["p_word"] != $_POST["conf_pword"])
        {
          $message="Passwords Don't Match";
         
        }

      else if( strlen($_POST["p_word"])<5)
        {
            $message= ("Password must be at least 5 characters long");
        }

        else{
          $p_wrd=val_input($_POST["p_word"]);
        }
      
      if(empty($_POST["mobile"]))
      {
        $message= "Enter Valid data for all fields";
      }
      else{

        $phne= val_input($_POST["mobile"]);
      }

      if(empty($_POST["email"]))
      {
        $message= "Email Required";
        
      }
      else if (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {

          $message = "Enter Valid Data for all fields";
          
        }
      else{
        $email= val_input($_POST["email"]);
      }
        if(empty($_POST["country"])){
            $country= "United States";
        }
        else
        {
          $country=val_input($_POST["country"]);
        }
      

      if(empty($_POST["u_name"]))
      {
        $message= "Username Required";
        
      }
      else if($_POST["u_name"]==$_POST["p_word"]){

        $message= "Username same as Password, Choose another Username";
        
      }

      else{

          $u_wrd= val_input($_POST["u_name"]);
          if (!preg_match ("/^[a-zA-Z ]*$/", $u_wrd)) {

              $message="Invalid Username";
          }
          $query = "SELECT u_name FROM members WHERE u_name='$u_wrd'";
          $result= @mysqli_query($dbc,$query);
         if ($result)
          {
          
            $rowcount=mysqli_num_rows($result);
              if($rowcount==0){
             
                                  
              }
            else{
              $message="Username already taken";
          
            }
          }else{
       // $msg="dint get there";
      }
          //}
      
        
      
    }


    if(!isset($message))
    {        
           $query = "INSERT INTO members (sponsor,first_name, second_name, email, p_word,u_name,phone,country)
                  VALUES ('$spons','$f_name', '$l_name', '$email' , SHA('$p_wrd'), '$u_wrd', '$phne','$country')";

              $result= @mysqli_query($dbc,$query);

               
                if($result){
                  
                        
                 header("location: login.php");
                  unset($_POST);
                 mysqli_close($dbc);
                 exit();
                }
                else
                {
                  echo "ERROR" ; 
                  mysqli_close($dbc);
                  exit();
                }




        
    }


         }

      
     }

    
 }


   

?>





  <!Doctype HTML>
  <html lang="en">
    <head>
      <meta charset="utf-8">

        <meta name="viewport" content="width=device-width, initial-scale=1  maximum-scale=1, user-scalable=no ">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

      <title> Create Account-Coindeep</title>
      <link rel="stylesheet" href="register.css" type="text/css"/>
     
      <link rel="stylesheet" href="Design/css/ionicons/css/ionicons.min.css"/>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

       
       

      
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
               
      </head>

     <body> 

      <div align="center" class="strict">
      <h4 ><?php if(isset($message)) echo $message; ?></h4>
       

    </div>

    <form id="" class="formular">
    <div align="center">
       <img src="Design/images/coin.png" alt="C-D">
      <strong><b><h1>Registration</h1></b></strong>
            
            </div>
        
        
      </form>
        <div align="center">
         <form id="formID" action="registration.php" class="formular" method="post">
        
              <label for="textfield">  Referred By </label>
              <?php if(isset($_GET['r'])!=''){ ?>

                   
              <script type="text/javascript">
                  $(document).ready(function(){
                  
                           
                      
                     var d= <?php $r= $_GET['r']; echo json_encode($r);?>;

                    
                    
                    var t= $("#usponsor").val(d);
                    
                  
                 });
                      
                      
            </script>
            <input type="text" name="sponsor_username" size="15" maxlength="15"  value="<?php $r= $_GET['r']; echo $r;?>" class="validate[required] text-input" required disabled/> 
          <?php }?>
          
           
           <?php if(isset($_GET['r'])=='') { ?>
            <input type="text" name="admin_sponsored" size="15" maxlength="15"  value="coindeepadmin" class="validate[required] text-input" required disabled /> 
          <?php }?>

            <input type="hidden" name="sponsor" id="usponsor" value=""/ >



           <br/>
           <input type="text" name="first_name" id="textfield" size="15" maxlength="15" value="<?php if(isset($_POST['first_name'])) echo $_POST['first_name'];?>" placeholder="First Name" class="validate[required,custom[onlyLetterSp]] text-input" />
           <br/>
            <input type="text" name="last_name" id="textfield2" size="15" maxlength="15" value="<?php if(isset($_POST['last_name'])) echo $_POST['last_name']; ?>" placeholder="Last Name" class="validate[required,custom[onlyLetterSp]] text-input" />

            <br/>
            <font color="#009933" size="2">( This is Your Login Password. )</font>
              <input type="password" name="p_word" id="password" size="15" maxlength="15" value="" placeholder="Password" class="validate[[required],minLength[7]] text-input"/>
           
          
          
            <br/>
            <input type="password" name="conf_pword" id="textfield5" size="15" maxlength="15" value="" placeholder="Confirm Password"  class="validate[required,equals[password],,minLength[7]] text-input" />
          
             <br/>

            <input type="text" name="u_name" id="textfield8" size="10" maxlength="10" value="<?php if(isset($_POST['u_name'])) echo $_POST['u_name']; ?>" placeholder="Username" class="validate[required,custom[onlyLetterSp]] text-input" />
         
            <br/>
           
            <input type="text" name="mobile" id="textfield7" size="15" maxlength="15" value="<?php if(isset($_POST['mobile'])) echo $_POST['mobile']; ?>" placeholder="Phone No(Include Country Code)" class="validate[required,custom[phone],maxSize[15],minSize[5]] text-input" />
            
            <br/>
            <input type="text" name="email" id="textfield6" size="30" maxlength="30" value="<?php if(isset($_POST['email'])) echo $_POST['email']; ?>" placeholder="E-mail Address" class="validate[required,custom[email]] text-input" />
          
            <br/>
            
             <input type="hidden" name="submitted" value="TRUE"/>

           

            <select id="drop_country" name="countries" class="select" style ="width: 300px" value="" class="validate[required]">
                      <option  value="1">Select Country</option><option value="2">Afghanistan</option><option value="3">Albania</option><option value="4">Algeria</option><option value="5">Andorra</option><option value="6">Angola</option><option value="7">Antigua and Barbuda</option><option value="8">Argentina</option><option value="9">Armenia</option><option value="10">Australia</option><option value="11">Austria</option><option value="12">Azerbaijan</option><option value="13">Bahamas</option><option value="14">Bahrain</option><option value="15">Bangladesh</option><option value="16">Barbados</option><option value="17">Belarus</option><option value="18">Belgium</option><option value="19">Belize</option><option value="20">Benin</option><option value="21">Bhutan</option><option value="22">Bolivia</option><option value="23">Bosnia and Herzegovina</option><option value="24">Botswana</option><option value="25">Brazil</option><option value="26">Brunei Darussalam</option><option value="27">Bulgaria</option><option value="28">Burkina Faso</option><option value="29">Burundi</option><option value="30">Cabo Verde</option><option value="31">Cambodia</option><option value="32">Cameroon</option><option value="33">Canada</option><option value="34">Central African Republic</option><option value="35">Chad</option><option value="36">Chile</option><option value="37">China</option><option value="38">Colombia</option><option value="39">Comoros</option><option value="40">Congo</option><option value="41">Costa Rica</option><option value="42">Cote d'Ivoire</option><option value="43">Croatia</option><option value="44">Cuba</option><option value="45">Cyprus</option><option value="46">Czech Republic</option><option value="47">Democratic People's Republic of Korea (North Korea)</option><option value="48">Democratic Republic of the Cong</option><option value="49">Denmark</option><option value="50">Djibouti</option><option value="51">Dominica</option><option value="52">Dominican Republic</option><option value="53">Ecuador</option><option value="54">Egypt</option><option value="55">El Salvador</option><option value="56">Equatorial Guinea</option><option value="57">Eritrea</option><option value="58">Estonia</option><option value="59">Ethiopia</option><option value="60">Fiji</option><option value="61">Finland</option><option value="62">France</option><option value="63">Gabon</option><option value="64">Gambia</option><option value="65">Georgia</option><option value="66">Germany</option><option value="67">Ghana</option><option value="68">Greece</option><option value="69">Grenada</option><option value="70">Guatemala</option><option value="71">Guinea</option><option value="72">Guinea-Bissau</option><option value="73">Guyana</option><option value="74">Haiti</option><option value="75">Honduras</option><option value="76">Hungary</option><option value="77">Iceland</option><option value="78">India</option><option value="79">Indonesia</option><option value="80">Iran</option><option value="81">Iraq</option><option value="82">Ireland</option><option value="83">Israel</option><option value="84">Italy</option><option value="85">Jamaica</option><option value="86">Japan</option><option value="87">Jordan</option><option value="88">Kazakhstan</option><option value="89">Kenya</option><option value="90">Kiribati</option><option value="91">Kuwait</option><option value="92">Kyrgyzstan</option><option value="93">Lao People's Democratic Republic (Laos)</option><option value="94">Latvia</option><option value="95">Lebanon</option><option value="96">Lesotho</option><option value="97">Liberia</option><option value="98">Libya</option><option value="99">Liechtenstein</option><option value="100">Lithuania</option><option value="101">Luxembourg</option><option value="102">Macedonia</option><option value="103">Madagascar</option><option value="104">Malawi</option><option value="105">Malaysia</option><option value="106">Maldives</option><option value="107">Mali</option><option value="108">Malta</option><option value="109">Marshall Islands</option><option value="110">Mauritania</option><option value="111">Mauritius</option><option value="112">Mexico</option><option value="113">Micronesia (Federated States of)</option><option value="114">Monaco</option><option value="115">Mongolia</option><option value="116">Montenegro</option><option value="117">Morocco</option><option value="118">Mozambique</option><option value="119">Myanmar</option><option value="120">Namibia</option><option value="121">Nauru</option><option value="122">Nepal</option><option value="123">Netherlands</option><option value="124">New Zealand</option><option value="125">Nicaragua</option><option value="126">Niger</option><option value="127">Nigeria</option><option value="128">Norway</option><option value="129">Oman</option><option value="130">Pakistan</option><option value="131">Palau</option><option value="132">Panama</option><option value="133">Papua New Guinea</option><option value="134">Paraguay</option><option value="135">Peru</option><option value="136">Philippines</option><option value="137">Poland</option><option value="138">Portugal</option><option value="139">Qatar</option><option value="140">Republic of Korea (South Korea)</option><option value="141">Republic of Moldova</option><option value="142">Romania</option><option value="143">Russian Federation</option><option value="144">Rwanda</option><option value="145">Saint Kitts and Nevis</option><option value="146">Saint Lucia</option><option value="147">Saint Vincent and the Grenadines</option><option value="148">Samoa</option><option value="149">San Marino</option><option value="150">Sao Tome and Principe</option><option value="151">Saudi Arabia</option><option value="152">Senegal</option><option value="153">Serbia</option><option value="154">Seychelles</option><option value="155">Sierra Leone</option><option value="156">Singapore</option><option value="157">Slovakia</option><option value="158">Slovenia</option><option value="159">Solomon Islands</option><option value="160">Somalia</option><option value="161">South Africa</option><option value="162">South Sudan</option><option value="163">Spain</option><option value="164">Sri Lanka</option><option value="165">Sudan</option><option value="166">Suriname</option><option value="167">Swaziland</option><option value="168">Sweden</option><option value="169">Switzerland</option><option value="170">Syrian Arab Republic</option><option value="171">Tajikistan</option><option value="172">Thailand</option><option value="173">Timor-Leste</option><option value="174">Togo</option><option value="175">Tonga</option><option value="176">Trinidad and Tobago</option><option value="177">Tunisia</option><option value="178">Turkey</option><option value="179">Turkmenistan</option><option value="180">Tuvalu</option><option value="181">Uganda</option><option value="182">Ukraine</option><option value="183">United Arab Emirates</option><option value="184">United Kingdom </option><option value="185">United Republic of Tanzania</option><option  selected value="186">United States</option><option value="187">Uruguay</option><option value="188">Uzbekistan</option><option value="189">Vanuatu</option><option value="190">Venezuela</option><option value="191">Vietnam</option><option value="192">Yemen</option><option value="193">Zambia</option><option value="194">Zimbabwe</option>                    
            </select><input type="hidden" name="country" id="country_hidden"/ >
            
             <br/>
           
             <br/>
             <div class="strict"><p><h4> By Clicking on Register you are Agreeing to our Terms and Conditions as stated here  <a href="#"> Terms and Condtions </h4></a></p>
             </div>
             <br/>

              <input type="submit" name="submit"  value="REGISTER NOW" id="click"  class="button strict" />
              <br/>

              <div align= 'left' class="strict">
                <a href="login.php" class="" title="">
              <i class="icon ion-log-in"></i> Login
            </a>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <!-- &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -->
            <a href="https://coindeep.com" class="" title="">
              <i class="icon ion-home"></i> Home
            </a>
      </div>
               
             <script type="text/javascript">
                  $(document).ready(function(){
                  
                    $("#drop_country").change(function(){
                        
                    
                    var drop= $("#drop_country :selected").text();
                     $("#country_hidden").val($("#drop_country :selected").text());
                    
                 
                    });
                    
                });
                      
                      
            </script>   
     
      </form>
      </div>
      


            

  </body>
  </html>

