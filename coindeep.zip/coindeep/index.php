<!DOCTYPE html>
<!--[if IE 8 ]><html class="no-js oldie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="no-js oldie ie9" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>

   <!--- basic page needs
   ================================================== -->
   <meta charset="utf-8">
  <title>CoinDeep</title>
  <meta name="description" content="">  
  <meta name="author" content="">

   <!-- mobile specific metas
   ================================================== -->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

          <!-- jQuery library -->
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

          <!-- Latest compiled JavaScript -->
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
                 
     

  <!-- CSS
   ================================================== -->
   <link rel="stylesheet" href="Design/css/base.css">  
   <link rel="stylesheet" href="Design/css/main.css">
   <link rel="stylesheet" href="Design/css/vendor.css">     

   <!-- script
   ================================================== -->
 <!--  <script src="Design/js/modernizr.js"></script> -->

   <!-- favicons
  ================================================== -->
  <link rel="icon" type="image/png" href="https://coindeep.com/Design/coindeep.jpg">

</head>

<body id="top">

  <!-- header 
   ================================================== -->
   <header>

    <div class="row">

      <div class="logo">
           <a href="https://coindeep.com">CoinDeep</a>
        </div>

      <nav id="main-nav-wrap">
        <ul class="main-navigation">
          <li class="current"><a class="smoothscroll"  href="https://coindeep.com" title="">Home</a></li>
          <li><a class="smoothscroll"  href="#process" title="">Philsophy</a></li>
          <li><a class="smoothscroll"  href="https://coindeep.com#features" title="">Features</a></li>
          <li><a class="smoothscroll"  href="how-it-works.php" title="">How it Works</a></li>
          <li><a class="smoothscroll"  href="faq.php" title="">FAQ</a></li>         
          <li class="highlight with-sep"><a href="registration.php" title="">Sign Up</a></li>
               <li class="highlight with-sep"><a href="login.php" title="">Login</a></li>           
        </ul>
      </nav>

      <a class="menu-toggle" href="#"><span></span></a>
      
    </div>    
    
   </header> <!-- /header -->

  <!-- intro section
   ================================================== -->
   <section id="intro">

    <div class="shadow-overlay"></div>

    <div class="intro-content">
      <div class="row">

        <div class="col-twelve">

          <h4>Welcome to CoinDeep</h4>
          <h1>A Simplified and Innovative way to Earn bitcoins</h1>
               <div class="action">
          <a class="button stroke smoothscroll" href="registration.php" title="">Create an Account</a> <!-- button stroke smoothscrool was class b4 -->
               </div>
        </div>  
        
      </div>          
    </div> 

    <!-- Modal Popup
     ========================================================= -->

      <div id="video-popup" class="popup-modal mfp-hide">

       <div class="fluid-video-wrapper">
            <iframe src="http://player.vimeo.com/video/14592941?title=0&amp;byline=0&amp;portrait=0&amp;color=faec09" width="500" height="281" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe> 
         </div>        

         <a class="close-popup">Close</a>         

     </div> <!-- /video-popup -->     

   </section> <!-- /intro -->


   <!-- Philosophy Section
   ================================================== -->
   <section id="process">  

    <div class="row section-intro">
      <div class="col-twelve with-bottom-line">

        <h5>What is Entails</h5>
        <h1>100% return in 8 days</h1>

        <p class="lead"> Start Earning 100% of your investments in 4 Simple Steps</p>

      </div>      
    </div>

    <div class="row process-content">

      <div class="left-side">

        <div class="item" data-item="1">

          <h5>Sign Up</h5>

          <p> Create an account with a valid bitcoin address (Blockcahin.info recommended) and input other valid details</p>
            
        </div>

        <div class="item" data-item="2">

          <h5>Login</h5>

          <p>Login into your account where you would be taking to your dashboard</p>
            
        </div>
          
      </div> <!-- /left-side -->
      
      <div class="right-side">
          
        <div class="item" data-item="3">

          <h5>Make Donation(PH,Re-ph)</h5>

          <p>Click on the Ph button to make donation <b> Minimum amount of $10, Maximum ammount of $100.</b> Redonate Same Amount 
                  or Higher 5 days after your initial Donation. (You Would Get 100% Back for Each Donation)</p>
            
        </div>

        <div class="item" data-item="4">

          <h5>Withdrawal(GH)</h5>

          <p>Get 100% of your investment after 8 days GUARANTEED.</p>
            
        </div>

      </div> <!-- /right-side -->  

      <div class="image-part"></div>        

    </div> <!-- /process-content --> 

   </section> <!-- /process-->    


   <!-- features Section
   ================================================== -->
  <section id="features">

    <div class="row section-intro">
      <div class="col-twelve with-bottom-line">

        <h5>Features</h5>
        <h1>Great features you'll love.</h1>

        <p class="lead"> We offer the very best features from Security to Great Support, Fast Withdrawal and Many More.</p>

      </div>      
    </div>

    <div class="row features-content">

      <div class="features-list block-1-3 block-s-1-2 block-tab-full group">

          <div class="bgrid feature"> 

            <span class="icon"><i class="icon-window"></i></span>            

              <div class="service-content"> 

                 <h3 class="h05">Fast Withdrawal</h3>

                <p> Using the Blockchain Payment Api, Each member gets Payments to Their wallet Fast and Easily, Maximum of 24hrs for Payments to show up in your wallet
                     (Takes lesser time in most cases).
              </p>
              
            </div>             

        </div> <!-- /bgrid -->

        <div class="bgrid feature"> 

          <span class="icon"><i class="icon-paint-brush"></i></span>                          

              <div class="service-content"> 
                <h3 class="h05">Great Technology</h3>  

                <p>We Make use of the very best technologies to serve you better. We use the blockchain payment integration Technology 
                     for fast payments and confirmations coupled with Fast and Secure Servers. 
              </p>

              
              </div>                            

         </div> <!-- /bgrid -->

         <div class="bgrid feature">

          <span class="icon"><i class="icon-user"></i></span>               

              <div class="service-content">
                <h3 class="h05">Great Support</h3>

                <p> Have any complaints or Enquiries? We offer both Chat and Email Supports. Fast and Reliable, Email Support Replies typically within 24hrs(or less depending on Traffic). Chat Support is available 24/7.
                </p> 

                
              </div>                               

         </div> <!-- /bgrid -->

        <div class="bgrid feature">

          <span class="icon"><i class="icon-file"></i></span>               

              <div class="service-content">
                <h3 class="h05">We are Social</h3>

                <p>You can find us on Facebook, Twitter and Whatsapp. We offer our clients the opporturnity to connect and get in touch with us personaly through The Whatsapp Group And Facebook Page. Our Agents would be Available on both platforms to chat and provide Answers to your queries.
              </p> 

              
              </div>                

        </div> <!-- /bgrid -->

         <div class="bgrid feature">

          <span class="icon"><i class="icon-layers"></i></span>             

              <div class="service-content"> 
                <h3 class="h05">Strict And Abidable Rules</h3>

                
                  <p>In other to Provide the very Best Experince for our Custormers their Are Strict Rules Put in Place to Get Rid of defaulters and Purify the platform of unserious participants.

                  </p> 
                  <p> <b> 1 Uploading of fake or counterfiet hash code Attracts suspension of such members Account
                          <p>2 Failure to Make Donationa within the Stipulated time Attracts suspension of such members Account <a href="how-it-works.php">Learn More</a> </p>
                           </b>
                  </p>

                
              </div>                 

         </div> <!-- /bgrid -->


         <div class="bgrid feature">

          <span class="icon"><i class="icon-book"></i></span>                

              <div class="service-content">
                  <h3 class="h05">Referral Comissions</h3>

                  <p> Get 5% commision on donations of every participants you Refer.There are No max number of referrals you can get. This is a way of Rewarding you for helping us Expand our Community :).
                  </p> 
                
              </div>

         </div> <!-- /bgrid -->

        

        </div> <!-- features-list -->
      
    </div> <!-- features-content -->
    
  </section> <!-- /features -->


   <!-- Testimonials Section
   ================================================== -->
   <section id="testimonials">

    <div class="row">
      <div class="col-twelve">
        <h2 class="h01">Hear What Participant's Say.</h2>
      </div>      
    </div>    

      <div class="row flex-container">
    
         <div id="testimonial-slider" class="flexslider">

            <ul class="slides">

               <li>
                <div class="testimonial-author">
                      <img src="images/avatars/avatar-1.jpg" alt="Author image">
                      <div class="author-info">
                        Pelumi Kegunro
                        <span class="position"></span>
                      </div>
                  </div>

                  <p>
                 Coindeep Rocks!!! i decided to test the platform with just $10, after 8 days, i applied for withdrawal and viola i was paid
                 took less than 15minutes for the payment to show up in my wallet.Now am getting serious with coindeep and ready to invest and invest again
                 Thank you Coindeep.
              </li> <!-- /slide -->

               <li> 

                <div class="testimonial-author">
                      <img src="Design/images/avatars/avatar-2.jpg" alt="Author image">
                      <div class="author-info">
                        Bayeh Kilenshra
                        <span></span>
                      </div>
                  </div> 

                  <p>
                  I was scared to invest at first, but a i did invest and i have been paid. this is my 3rd time of investing and
                  i was paid my 100% profit. Thank you Coindeep.    
                  </p>
                                         
               </li> <!-- /slide -->

            </ul> <!-- /slides -->

         </div> <!-- /testimonial-slider -->         
        
      </div> <!-- /flex-container -->

   </section> <!-- /testimonials -->


   
   

   <!-- footer
   ================================================== -->
 

   <?php include('footer.php');?>

   <div id="preloader"> 
      <div id="loader"></div>
   </div> 

   <!-- Java Script
   ================================================== --> 
   <script src="Design/js/jquery-1.11.3.min.js"></script>
   <script src="Design/js/jquery-migrate-1.2.1.min.js"></script>
   <script src="Design/js/plugins.js"></script>
   <script src="Design/js/main.js"></script>

</body>

</html>