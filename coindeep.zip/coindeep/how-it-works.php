	<?php
		require_once('header.php');
	?>
	<div>
	<section id="faq">

	   	<div class="row section-intro">
	   		<div class="col-twelve with-bottom-line">

	   			<h5>Always Participate with your Spare Money Only</h5>
	   			<h1>Coindeep - How it Works</h1>

	   			<p class="">COINDEEP is not a bank, COINDEEP does not collect your money,COINDEEP is not an ONLINE BUSINESS, HYIP, investment or MLM program. COINDEEP is a community where people help each other.COINDEEP gives you a technical basic program, which helps millions of participants worldwide to find those who NEED help, and those who are ready to PROVIDE help for FREE. All transferred funds to another participants are your help given by your own good will to another one, absolutely gratis. If you are completely confident and certain in your actions and make your mind to participate, we kindly ask you to study carefully all warnings and instructions first.</p>

	   		</div>   		
	   	</div>

	   
	   <section id="faq">

	   				<div class="row section-intro">
	   					<div class="col-twelve with-bottom-line">

	   			
	   			<h1>Providing Help (PH)</h1>
	   			</div>   		
	   		</div>

	   	<div class="row faq-content">

	   		<div class="q-and-a block-1-2 block-tab-full group">

	   			<div class="bgrid">

	   				<h3>Providing Help (PH) </h3>

	   				<p> Participants can PH (Provide Help) from 10$ to 100$ Maximum </p>
	   				<p> PH assignments will be paired within 5 minutes from the moment you submitted the confirm amount</p>
	   				<p> When paired, You have 24 hours max to send the donation and the exact amount</p>
	   				<p> After Sending the donation you input the hash code of the transaction for confirmation</p>
	   				<p> Using the Blockchain Api the transaction is scrutinized and processed</p>
	   				<p> Your transaction is going to be confirmed after being processed and sent to the reciever</p>


	   			</div>

	   			<div class="bgrid">

	   				<h3>Re-Ph (Recommitment)</h3>

	   				<p>RePH (Recommit) will be made after 5 days from the last confirmed PH</p>
	   				<p>RePh amount can only be equal or greater than your first donation amount</p>
	   				<p> You need to Re-Ph in other to be able to withdraw your first ph profit</p>

	   			</div>
	   		

	   	<section id="faq">

	   				<div class="row section-intro">
	   					<div class="col-twelve with-bottom-line">

	   			
	   			<h1>Getting Help (GH)</h1>
	   			</div>   		
	   				</div>
	   		<div class="row faq-content">

	   		<div class="q-and-a block-1-2 block-tab-full group">

	   			<div class="bgrid">

	   				<h3>GETTING HELP</h3>

	   				<p>Participants can GH (Get Help) from 20$ to 200$ Maximum</p>
	   				<p>GH transactions will be processed and paired within 5 minutes (max of 24hrs) from the moment you submitted your request</p>
	   				<p> Profits would be sent to your BTC Address automatically</p>
	   			</div>

	   			<div class="bgrid">

	   				<h3>Get Help Legality</h3>

	   				<p> In other to be able to GH you must have re-ph as stated above</p>
	   				<p> GH amounts should be in Multiples of 10</p>

	   			</div>
	   		
	   			<section id="faq">

	   				<div class="row section-intro">
	   				<div class="col-twelve with-bottom-line">

	   			
	   			<h1>Donation Growth Rate</h1>
	   			</div>   		
	   				</div>
	   		<div class="row faq-content">

	   		<div class="q-and-a block-1-2 block-tab-full group">
	   			<div class="bgrid">

	   				<h3>Growth Value</h3>

	   				<p>Total grwoth value is <b> 100% in 8 days</b></p>

	   			</div>
	            <div class="bgrid">

	               <h3>INSIGHT</h3>

	               <p> The Growing Rates are 12.5% daily: It means that your money will be 100% after 8 days and recommitment should be made after 5days when PH was confirm. The interest is accrued every minute but credited on every hour in your dashboard. Remember that pairing of assignment for your PH will be within 5 minutes.

					Commitment Amount is 10$ to 100$ </p>

	            </div>
	            	<section id="faq">

	   				<div class="row section-intro">
	   				<div class="col-twelve with-bottom-line">

	   			
	   			<h1>Bonus</h1>
	   			</div>   		
	   				</div>

	   				<div class="row faq-content">

	   				<div class="q-and-a block-1-2 block-tab-full group">
	   				<div class="bgrid">

	   				<h3>Direct Bonus</h3>

	   				<p><b>Direct Bonus is 5%</b> For each new member that you have invited to the platform,you get 5% of all their comfirmed Ph transactions to your account.</p>

	   			</div>
	   			<div class="bgrid">
	   				<h3> Referral Limit</h3>
	   					<p> There are not max amount of referrals you can get, refer as much as you can and earn exclusive bonuses</p>
	   				</div>


	   				<section id="faq">

	   				<div class="row section-intro">
	   				<div class="col-twelve with-bottom-line">

	   			
	   			<h1>MISC</h1>
	   			</div>   		
	   				</div>

	   				<div class="row faq-content">

	   				<div class="q-and-a block-1-2 block-tab-full group">

	   				<div class="bgrid">

	   				<h3>What You Should Know</h3>

	   				<p><b>Multiple accounts are permitted</b></p>
	   				<p><b>No Admin Fees, No Hidden Fees, No Transaction Processing fees</b></p>

	   				</div>

	   				<div class="bgrid">
	   				<h3> About Blockchain</h3>
	   					<p>A good Knowledge about how the bitcoin tech works is an added advantage to participants.Nevertheless the Platform has been simplified for participants with little or no knowledge of how bitcoin works</p>
	   					<p> We Recommend the Blockchain.info wallet due to its innovative technology aimed at making bitcoin transactions and confirmations easy</p>
	   				</div>









	   		</div> <!-- /q-and-a --> 
	   		
	   	</div> <!-- /faq-content --> 

	   	 <!-- /section-ads --> 

	   	</section>
	   </section>
	</section>
</section>
</section>
	   </section> <!-- /faq --> 
	</div>

	   <div align='buttom'>
	   	<?php require_once('footer.php');?>
	   </div>

	  