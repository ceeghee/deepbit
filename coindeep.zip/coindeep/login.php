<?php
		session_start();
		include ("validation/header.php");
    require_once('loginval.php');
		$msg="";

?>


 <!Doctype HTML>
    <html>
      <head>
        <title> Login-Coindeep</title>
        <link rel="stylesheet" href="register.css" type="text/css"/>
        <link rel="stylesheet" href="Design/css/ionicons/css/ionicons.min.css"/>
       
        </head>

       <body> 

        <div align="center">
        <h4><?php echo $msg ?></h4>

      </div>

      <form id="" class="formular" method="">
      <div align="center">
         <img src="Design/images/coindeep.jpg" alt="dpc">
        <strong><b><h1>Login</h1></b></strong>
              
              </div>
          
          
        </form>
          <div align="center">
           <form id="formID" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="formular" method="post">

                 <input type="text" name="u_name" id="textfield8" size="10" maxlength="10" value="" placeholder="Username" class="validate[required,custom[onlyLetterSp]] text-input" />
             

           
              <br/>
             
               <br/>

                <input type="password" name="p_word" id="password" size="15" maxlength="15" value="" placeholder="Password" class="validate[required,minLength[7]] text-input"/>
                <br/>
                <input type="submit" name="submit"  value="LOGIN" id="click"  class="button"/>
               
               <p>
        &nbsp;<br />&nbsp;
                  <div align= 'left'>
                  <a href="registration.php" class="" title="">
                <i class="icon ion-android-open"></i> Register
              </a>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <a href="index.php" class="" title="">
                <i class="icon ion-home"></i> Home
              </a>
        </div>
                 
              </p>
        
         
           
        </form>
        </div>





    </body>
    </html>


