<?php 
      include("header.php");
?>


<section id="faq">

   	<div class="row section-intro" >
   		<div class="col-twelve with-bottom-line">

   			<h5>Faq</h5>
   			<h1>Questions and Answers</h1>

   			<p class="lead">Quick Answers to Regular and Common Questions</p>

   		</div>   		
   	</div>

   	<div class="row faq-content">

   		<div class="q-and-a block-1-2 block-tab-full group">

   			<div class="bgrid">

   				<h3>How do i make Donations</h3>

   				<p>Once you are logged on, click on the ph button, Enter the amount to donate and submit.</p>

   			</div>

   			<div class="bgrid">

   				<h3>How does the Recommitment(Re-ph) work?</h3>

   				<p>5 days from your first donation, each member is expected to to re-donate same amount or higher again, just click on the reph button on the fifth day and input amount to re-donate.</p>

   			</div>

   			<div class="bgrid">

   				<h3>Why do i have To Redonate</h3>

   				<p>Re-donation is a way to sustain the system and keep it healthy, it helps members get committed to the platform, it also helps in balancing the platform payments schedule.</p>

   			</div>

   			<div class="bgrid">

   				<h3>What if i Decide not to Re-donate(re-ph)</h3>

   				<p> You Can decide not to re-donate, but at the expense of you first Ph. Meaning if you decide not to Re-Ph, you won't be able to withdraw your first Ph when its fully Matured.</p>

   			</div>

   			<div class="bgrid">

   				<h3>How long does it take to receive payments.</h3>

   				<p>Maximum time to receive payments is 24hrs, if a member fails to send donations to you when you paired, after 24hrs you would be re-paired with another member to receive donations.</p>

   			</div>
            <div class="bgrid">

               <h3>How do i Know that my Donation(Ph) has been confirmed?</h3>

               <p>Once you make donation and input the Hash code of your transaction and your donation gets confirmed your 100% profit begins to grow by 12.5% daily.</p>

            </div>

   		</div> <!-- /q-and-a --> 
   		
   	</div> <!-- /faq-content --> 

   	 <!-- /section-ads --> 


   </section> <!-- /faq --> 

   <?php require_once('footer.php');?>
