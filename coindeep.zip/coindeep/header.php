<!DOCTYPE html>
<!--[if IE 8 ]><html class="no-js oldie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="no-js oldie ie9" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>

   <!--- basic page needs
   ================================================== -->
   <meta charset="utf-8">
	<title>CoinDeep</title>
	<meta name="description" content="">  
	<meta name="author" content="">

   <!-- mobile specific metas
   ================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">


          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

          <!-- jQuery library -->
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

          <!-- Latest compiled JavaScript -->
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
                 
     

 	<!-- CSS
   ================================================== -->
   <link rel="stylesheet" href="Design/css/base.css">  
   <link rel="stylesheet" href="Design/css/main.css">
   <link rel="stylesheet" href="Design/css/vendor.css">     

   <!-- script
   ================================================== -->
	

   <!-- favicons
	================================================== -->
	<link rel="icon" type="image/png" href="Design/coindeep.jpg">

</head>

<body id="top">

	<!-- header 
   ================================================== -->
   <header>

   	<div class="row">

   		<div class="logo">
	         <a href="http://coindeep.com">CoinDeep</a>
	      </div>

	   	<nav id="main-nav-wrap">
				<ul class="main-navigation">
					<li class="current"><a class="smoothscroll"  href="http://coindeep.com" title="">Home</a></li>
					<li><a class="smoothscroll"  href="#process" title="">Philsophy</a></li>
					<li><a class="smoothscroll"  href="http://coindeep.com#features" title="">Features</a></li>
					<li><a class="smoothscroll"  href="how-it-works.php" title="">How it Works</a></li>
					<li><a class="smoothscroll"  href="faq.php" title="">FAQ</a></li>					
					<li class="highlight with-sep"><a href="registration.php" title="">Sign Up</a></li>
               <li class="highlight with-sep"><a href="login.php" title="">Login</a></li> 					
				</ul>
			</nav>

			<a class="menu-toggle" href="#"><span></span></a>
   		
   	</div>   	
   	
   </header> <!-- /header -->


    <!-- Java Script
   ================================================== --> 
   <script src="Design/js/jquery-1.11.3.min.js"></script>
   <script src="Design/js/jquery-migrate-1.2.1.min.js"></script>
   <script src="Design/js/plugins.js"></script>
   <script src="Design/js/main.js"></script>
</body>
</html>