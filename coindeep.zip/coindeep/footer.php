<!DOCTYPE html>
<!--[if IE 8 ]><html class="no-js oldie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="no-js oldie ie9" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>

   <!--- basic page needs
   ================================================== -->
   <meta charset="utf-8">
	<title>CoinDeep</title>
	<meta name="description" content="">  
	<meta name="author" content="">

   <!-- mobile specific metas
   ================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

 	<!-- CSS
   ================================================== -->
   <link rel="stylesheet" href="Design/css/base.css">  
   <link rel="stylesheet" href="Design/css/main.css">
   <link rel="stylesheet" href="Design/css/vendor.css">     

   <!-- script
   ================================================== -->
	

   <!-- favicons
	================================================== -->
	<link rel="icon" type="image/png" href="Design/coindeep.jpg">

</head>

<body id="top">

  <footer>

   	<div class="footer-main">

   		<div class="row">  

	      	<div class="col-four tab-full mob-full footer-info">            

	            <div class="footer-logo"></div>

	            <p>
		        	<i>&nbsp; Contacts<br>
            	Support@coindeep.com<br>
		        	Contact@coindeep.com
		        	</i></p>

		      </div> <!-- /footer-info -->

	      	<div class="col-two tab-1-3 mob-1-2 site-links">

	      		<h4>Site Links</h4>

	      		<ul>
	      			<li><a href="about-us.php">About Us</a></li>
						<li><a href="how-it-works.php">How it works</a></li>
						<li><a href="faq.php">FAQ</a></li>
						<li><a href="terms.php">Terms</a></li>
						<li><a href="Blockchain.info">Blockchain</a></li>
					</ul>

	      	</div> <!-- /site-links -->  

	      	<div class="col-two tab-1-3 mob-1-2 social-links">

	      		<h4>Social</h4>

	      		<ul>
	      			<li><a href="#">Twitter</a></li>
						<li><a href="#">Facebook</a></li>
						<li><a href="#">Whatsapp</a></li>
						<li><a href="#">Telegram</a></li>
						
					</ul>
	      	           	
	      	</div> <!-- /social --> 

	      	<div class="col-four tab-1-3 mob-full footer-subscribe">

	      		<h4>Security</h4>

	      		<p></p>

	      		<div class="subscribe-form">
	      	
	      			<a href="#" onclick="window.open('https://www.sitelock.com/verify.php?site=coindeep.com','SiteLock','width=600,height=600,left=160,top=170');" >
                     <img class="img-responsive" alt="SiteLock" title="SiteLock" src="//shield.sitelock.com/shield/coindeep.com" /></a>

	      		</div>	      		
	      	           	
	      	</div> <!-- /subscribe -->         

	      </div> <!-- /row -->

   	</div> <!-- /footer-main -->


      <div class="footer-bottom">

      	<div class="row">

      		<div class="col-twelve">
	      		<div class="copyright">
		         	<span>© Copyright CoinDeep 2017.</span> <!-- made changes here-->
		         		         	
		         </div>

		         <div id="go-top" style="display: block;">
		            <a class="smoothscroll" title="Back to Top" href="#top"><i class="icon ion-android-arrow-up"></i></a>
		         </div>         
	      	</div>

      	</div> <!-- /footer-bottom -->     	

      </div>

   </footer>  
</body>
</html>