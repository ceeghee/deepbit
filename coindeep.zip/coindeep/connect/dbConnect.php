<?php
	
	DEFINE ("DB_HOST", "localhost");
	DEFINE ("DB_USER","root");
	DEFINE ('DB_PASSWORD', "chukwuemeka");
	DEFINE ("DB_NAME", "coindeep");

	$dbc = @mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME)
	OR die("Server Error");

		function escape_data ($data) {


		if (function_exists('mysql_real_escape_string')) {

		global $dbc; // Need the connection.

		$data = mysqli_real_escape_string(trim($data), $dbc);

		$data = strip_tags($data);

		} else {

		$data = mysqli_real_escape_string(trim($data),$dbc);
				

		$data = strip_tags($data);

		}

		 

		// Return the escaped value.

		return $data;



		

}

?>