-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2017 at 09:07 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 7.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coindeep`
--

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `first_name` varchar(20) NOT NULL,
  `second_name` varchar(20) NOT NULL,
  `p_word` varchar(20) NOT NULL,
  `u_name` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(60) NOT NULL,
  `country` varchar(30) NOT NULL,
  `mem_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`first_name`, `second_name`, `p_word`, `u_name`, `phone`, `email`, `country`, `mem_id`) VALUES
('balogun', 'james', '8944ff3774ff35596c1f', '- OR', '+234 8165795629', 'goodluck.ekene@gmail.com', '', 86),
('balogun', 'james', '8944ff3774ff35596c1f', '$', '+234 8165795629', 'goodluck.ekene@gmail.com', '', 87),
('balogun', 'james', '8944ff3774ff35596c1f', '- OR -', '+234 8165795629', 'goodluck.ekene@gmail.com', '', 88),
('balogun', 'james', '8944ff3774ff35596c1f', 'jkjkjh', '/', 'goodluck.ekene@gmail.com', '', 89),
('balogun', 'james', '8944ff3774ff35596c1f', 'liokiusd', '+234 8165795629', 'goodluck.ekene@gmail.com', '', 90),
('Chukwuemeka', 'Ekene', 'f3d06289f6f68bbfd0ef', 'bangali', '+234 8165795629', 'techsavvy1997@gmail.com', '', 91),
('Chukwuemeka', 'Ekene', '8944ff3774ff35596c1f', 'bangaliz', '+234 8165795629', 'techsavvy1997@gmail.com', '', 92),
('Chukwuemeka', 'Ekene', '8944ff3774ff35596c1f', 'bangaliza', '+234 8165795629', 'techsavvy1997@gmail.com', '', 93);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`mem_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `mem_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
